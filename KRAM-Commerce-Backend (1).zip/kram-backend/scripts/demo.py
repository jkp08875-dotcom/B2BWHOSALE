"""Run against a local seeded API. Creates a real record in that database."""

import json, os
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from uuid import uuid4

base = os.getenv("API_BASE", "http://127.0.0.1:8000")
buyer = os.environ["BUYER_TOKEN"]
admin = os.environ["ADMIN_TOKEN"]


def call(method, path, token=None, body=None, extra=None):
    headers = {"Content-Type": "application/json", **(extra or {})}
    if token:
        headers["Authorization"] = "Bearer " + token
    req = Request(
        base + path,
        data=None if body is None else json.dumps(body).encode(),
        method=method,
        headers=headers,
    )
    try:
        with urlopen(req) as response:
            return json.load(response)
    except HTTPError as err:
        raise SystemExit(f"{method} {path}: {err.code} {err.read().decode()}") from err


if __name__ == "__main__":
    cart = {
        "lines": [{"variant_id": "20000000-0000-4000-8000-000000000001", "qty": 3}],
        "voucher_code": "SAVE10",
        "payment_mode": "deposit_50",
    }
    quote = call("POST", "/api/vouchers/validate", body=cart)
    print("Quote:", quote)
    order = call("POST", "/api/orders", buyer, cart, {"Idempotency-Key": str(uuid4())})
    number = order["order_no"]
    path = "/api/orders/" + number
    for stage, amount in [
        ("deposit", quote["due_now"]),
        ("balance", quote["remaining_after_first"]),
    ]:
        payment = call(
            "POST",
            path + "/payments",
            buyer,
            {
                "payment_stage": stage,
                "amount": str(amount),
                "transfer_ref": uuid4().hex,
                "slip_image_url": "https://example.test/demo-slip.jpg",
            },
        )
        call(
            "PATCH",
            "/api/admin/payments/" + payment["id"] + "/verify",
            admin,
            {"decision": "approved"},
        )
    print("Order:", number, "Balance:", call("GET", path, buyer)["balance_due"])
    print("SLA:", call("GET", path, buyer)["promised_delivery_at"])
    print("Ledger:", call("GET", "/api/ledger", buyer))
