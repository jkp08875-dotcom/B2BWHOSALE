from concurrent.futures import ThreadPoolExecutor
from uuid import uuid4
from decimal import Decimal
import psycopg
import pytest

VID = "20000000-0000-4000-8000-000000000001"


def ok(r):
    assert r.is_success, r.text
    return r.json()


def test_flow(system):
    c, (buyer, admin, staff), tx = system
    body = {"lines": [{"variant_id": VID, "qty": 3}], "voucher_code": "SAVE10"}
    q = ok(c.post("/api/vouchers/validate", json=body))
    assert float(q["subtotal"]) == 2070 and float(q["due_now"]) == 931.50
    h = {**buyer, "Idempotency-Key": str(uuid4())}
    o = ok(c.post("/api/orders", headers=h, json=body))
    assert ok(c.post("/api/orders", headers=h, json=body))["id"] == o["id"]
    assert (
        c.post(
            "/api/orders", headers=h, json={**body, "payment_mode": "full"}
        ).status_code
        == 409
    )
    path = "/api/orders/" + o["order_no"]

    def submit(stage, ref):
        return ok(
            c.post(
                path + "/payments",
                headers=buyer,
                json={
                    "payment_stage": stage,
                    "amount": "931.50",
                    "slip_image_url": "https://example.test/slip.jpg",
                    "transfer_ref": ref,
                },
            )
        )

    def verify(pid):
        return c.patch(
            "/api/admin/payments/" + pid + "/verify",
            headers=admin,
            json={"decision": "approved"},
        )

    p = submit("deposit", "REJECT")
    ok(
        c.patch(
            "/api/admin/payments/" + p["id"] + "/verify",
            headers=admin,
            json={"decision": "rejected", "reject_reason": "ยอดไม่ชัด"},
        )
    )
    p = submit("deposit", "D1")
    with ThreadPoolExecutor(4) as ex:
        assert all(r.status_code == 200 for r in ex.map(verify, [p["id"]] * 4))
    assert float(ok(c.get(path, headers=buyer))["balance_due"]) == 931.50
    ok(verify(submit("balance", "B1")["id"]))
    assert (
        c.post(
            "/api/admin/orders/" + o["order_no"] + "/sla-compensate", headers=staff
        ).status_code
        == 409
    )
    with tx() as db:
        db.execute(
            "UPDATE orders SET promised_delivery_at=now()-interval '1 minute' WHERE id=%s",
            (o["id"],),
        )
    from app.workers import sla_breach_monitor_job

    with ThreadPoolExecutor(3) as ex:
        assert sum(ex.map(lambda _: sla_breach_monitor_job(), range(3))) == 1
    assert (
        ok(
            c.post(
                "/api/admin/orders/" + o["order_no"] + "/sla-compensate", headers=staff
            )
        )["awarded"]
        == 0
    )
    root = "/api/admin/orders/" + o["order_no"]
    ok(
        c.post(
            root + "/ship",
            json={"carrier_name": "TEST", "tracking_no": "T1"},
            headers=staff,
        )
    )
    ok(c.post(root + "/deliver", headers=staff))
    assert ok(c.get(path, headers=buyer))["status"] == "delivered"
    assert len(ok(c.get("/api/notifications", headers=buyer))) == 1
    ok(c.post(root + "/refund", headers=admin))
    ok(c.post(root + "/refund", headers=admin))
    ledger = ok(c.get("/api/ledger", headers=buyer))
    assert sum(Decimal(str(r["amount_delta"])) for r in ledger) == 0
    assert c.get("/api/admin/ledger/export", headers=staff).status_code == 403
    assert "sla_compensation" in c.get("/api/admin/ledger/export", headers=admin).text
    assert c.get("/api/orders").status_code == 401
    assert c.get(path, headers=staff).status_code == 404
    with ThreadPoolExecutor(3) as ex:
        assert (
            sum(
                ex.map(
                    lambda _: ok(c.post("/api/checkin", headers=buyer))["awarded"],
                    range(3),
                )
            )
            == 10
        )
    for command in [
        "UPDATE ledger_entries SET reference_note='change'",
        "DELETE FROM ledger_entries",
        "TRUNCATE ledger_entries",
    ]:
        with pytest.raises(psycopg.errors.RaiseException), tx() as db:
            db.execute(command)


def test_competing_reservations(system):
    c, (buyer, admin, staff), tx = system
    p = ok(
        c.post(
            "/api/admin/products",
            headers=admin,
            json={
                "title": "ชา",
                "category": "เครื่องดื่ม",
                "origin_hub": "น่าน",
                "sla_delivery_hours": 24,
                "variants": [
                    {
                        "sku": "TEA-1",
                        "variant_name": "เล็ก",
                        "retail_price": "150",
                        "wholesale_price": "100",
                        "wholesale_min_qty": 3,
                        "stock_available": 1,
                        "weight_grams": 50,
                    }
                ],
            },
        )
    )
    vid = p["variants"][0]["id"]
    b = {"lines": [{"variant_id": vid, "qty": 1}]}

    def buy(_):
        return c.post(
            "/api/orders", headers={**buyer, "Idempotency-Key": str(uuid4())}, json=b
        )

    with ThreadPoolExecutor(6) as ex:
        results = list(ex.map(buy, range(12)))
    assert sorted(r.status_code for r in results) == [201] + [409] * 11
    o = next(r.json() for r in results if r.status_code == 201)
    with tx() as db:
        assert (
            db.execute(
                "SELECT stock_reserved FROM product_variants WHERE id=%s", (vid,)
            ).fetchone()["stock_reserved"]
            == 1
        )
        db.execute(
            "UPDATE orders SET expires_at=now()-interval '1 second' WHERE id=%s",
            (o["id"],),
        )
    from app.workers import release_expired_reservations_job

    with ThreadPoolExecutor(2) as ex:
        assert sum(ex.map(lambda _: release_expired_reservations_job(), range(2))) == 1
    o = ok(buy(1))
    ok(c.post("/api/orders/" + o["order_no"] + "/cancel", headers=buyer))
    assert (
        ok(c.get("/api/products?category=เครื่องดื่ม&origin_hub=น่าน&cold_chain=false"))[0][
            "variants"
        ][0]["stock_available"]
        == 1
    )
    assert ok(c.get("/api/media-posts"))[0]["product_id"] == VID.replace(
        "20000000", "10000000"
    )


def test_last_voucher_and_fixed_shipping(system):
    c, (buyer, admin, staff), tx = system
    with tx() as db:
        db.execute("""INSERT INTO vouchers(code,discount_type,discount_value,min_spend,max_quota,expires_at)
          VALUES('LAST','fixed',9999,0,1,now()+interval '1 day'),('SHIP','free_shipping',0,0,2,now()+interval '1 day')""")
    b = {
        "lines": [{"variant_id": VID, "qty": 1}],
        "voucher_code": "LAST",
        "payment_mode": "full",
    }
    assert (
        float(
            ok(c.post("/api/vouchers/validate", json={**b, "voucher_code": "SHIP"}))[
                "grand_total"
            ]
        )
        == 890
    )

    def buy(_):
        return c.post(
            "/api/orders", headers={**buyer, "Idempotency-Key": str(uuid4())}, json=b
        )

    with ThreadPoolExecutor(3) as ex:
        r = list(ex.map(buy, range(3)))
    assert sorted(x.status_code for x in r) == [201, 409, 409]
    o = next(x.json() for x in r if x.status_code == 201)
    assert float(o["grand_total"]) == 40
    ok(c.post("/api/orders/" + o["order_no"] + "/cancel", headers=buyer))
    assert float(ok(c.post("/api/vouchers/validate", json=b))["discount_amount"]) == 890


def test_full_slip_expiry_and_delivery(system):
    c, (buyer, admin, staff), tx = system

    def create():
        return ok(
            c.post(
                "/api/orders",
                headers={**buyer, "Idempotency-Key": str(uuid4())},
                json={"lines": [{"variant_id": VID, "qty": 1}], "payment_mode": "full"},
            )
        )

    def slip(o):
        return ok(
            c.post(
                "/api/orders/" + o["order_no"] + "/payments",
                headers=buyer,
                json={
                    "amount": "930.00",
                    "payment_stage": "full",
                    "transfer_ref": str(uuid4()),
                    "slip_image_url": "https://example.test/receipt",
                },
            )
        )

    from app.workers import release_expired_reservations_job

    o = create()
    p = slip(o)
    with tx() as db:
        db.execute(
            "UPDATE orders SET expires_at=now()-interval '1 second' WHERE id=%s",
            (o["id"],),
        )
    assert release_expired_reservations_job() == 1
    assert (
        c.patch(
            "/api/admin/payments/" + p["id"] + "/verify",
            headers=admin,
            json={"decision": "approved"},
        ).status_code
        == 409
    )
    o = create()
    p = slip(o)
    ok(
        c.patch(
            "/api/admin/payments/" + p["id"] + "/verify",
            headers=admin,
            json={"decision": "approved"},
        )
    )
    path = "/api/admin/orders/" + o["order_no"]
    ok(
        c.post(
            path + "/ship",
            headers=staff,
            json={"carrier_name": "EMS", "tracking_no": "OK"},
        )
    )
    assert ok(c.post(path + "/deliver", headers=staff))["balance_due"] == 0
    assert c.post(path + "/sla-compensate", headers=staff).status_code == 409
    stock = ok(c.get("/api/products?search=KRAM"))[0]["variants"][0]["stock_available"]
    assert (
        c.patch(
            "/api/admin/variants/" + VID + "/stock",
            headers=staff,
            json={"expected_available": stock + 1, "stock_available": 1},
        ).status_code
        == 409
    )
    assert (
        ok(
            c.patch(
                "/api/admin/variants/" + VID + "/stock",
                headers=staff,
                json={"expected_available": stock, "stock_available": stock},
            )
        )["stock_available"]
        == stock
    )
    assert (
        c.post(
            "/api/orders",
            headers={**buyer, "Idempotency-Key": str(uuid4())},
            json={"lines": [{"variant_id": VID, "qty": -1}]},
        ).status_code
        == 422
    )
