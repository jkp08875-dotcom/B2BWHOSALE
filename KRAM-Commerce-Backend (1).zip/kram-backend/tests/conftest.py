import os
from pathlib import Path
from uuid import uuid4
import pytest
import psycopg
from psycopg import sql
from psycopg.conninfo import make_conninfo
from fastapi.testclient import TestClient


@pytest.fixture(scope="session")
def system():
    url = os.environ["TEST_DATABASE_URL"]
    schema = "qa_" + uuid4().hex
    with psycopg.connect(url, autocommit=True) as root:
        root.execute(sql.SQL("CREATE SCHEMA {}").format(sql.Identifier(schema)))
        try:
            os.environ["DATABASE_URL"] = make_conninfo(
                url, options="-csearch_path=" + schema
            )
            from app.main import app
            from app.db import transaction
            from app.manage import migrate, seed, token

            with TestClient(app) as client:
                with transaction() as db:
                    migrate(db)
                    seed(db)
                    headers = [
                        {"Authorization": "Bearer " + token(db, p)}
                        for p in ("0800000001", "0800000002", "0800000003")
                    ]
                yield client, headers, transaction
        finally:
            root.execute(
                sql.SQL("DROP SCHEMA {} CASCADE").format(sql.Identifier(schema))
            )
