# KRAM Commerce Backend

FastAPI + Pydantic v2 + psycopg 3 + PostgreSQL 16 ใช้ได้กับฐาน PostgreSQL แยกสำหรับบริการนี้ สินค้าและสลิปใน seed เป็นข้อมูลจำลอง โปรเจกต์นี้เป็น backend แยกสำหรับนำไปเชื่อมหน้าร้านและหลังบ้าน KRAM

## รันด้วย Docker Compose

ต้องมี Docker Compose v2 คำสั่งตัวอย่างเป็น Bash บน Linux/macOS หรือ WSL

~~~bash
cp .env.example .env
docker compose up --build -d
docker compose run --rm api python -m app.manage seed
export BUYER_TOKEN="$(docker compose exec -T api python -m app.manage token 0800000001)"
export ADMIN_TOKEN="$(docker compose exec -T api python -m app.manage token 0800000002)"
python scripts/demo.py
~~~

เปิด http://localhost:8000/docs เพื่อทดลอง GET/POST/PATCH ผ่าน Swagger UI ใช้ Authorize และวาง token ของบทบาทที่ต้องการ OpenAPI JSON ที่ /openapi.json และไฟล์ openapi.json ในชุดส่งมอบระบุชนิดข้อมูล request/response validation และตัวอย่างโครงสร้าง input ตัวบริการรัน migration ตามลำดับก่อนเปิด API/worker บันทึก checksum ป้องกันการแก้ migration ที่ติดตั้งแล้ว

## ติดตั้งด้วย Python โดยตรง

สร้างฐาน PostgreSQL ว่างสำหรับ KRAM และตั้ง DATABASE_URL ใน .env ให้ตรงกับฐานนั้น

~~~bash
python3.12 -m venv .venv
source .venv/bin/activate
pip install -r requirements-test.txt
cp .env.example .env
python -m app.manage migrate
python -m app.manage seed
uvicorn app.main:app --port 8000
# เปิด terminal อีกหน้าที่ใช้ .venv และ .env เดียวกัน
python -m app.workers
~~~

หากใช้ Supabase ให้ใช้ DSN ฝั่งเซิร์ฟเวอร์ที่รองรับ transaction และ server-side cursor (direct หรือ session pooler) ติดตั้งในฐานหรือ schema เฉพาะและตั้ง search_path ให้ตรงกันทุก process อย่าเปิดตารางการขาย สลิป และ ledger ผ่าน Data API ให้ anon/authenticated สำหรับ deployment จริงให้แยก migration owner และ runtime role ให้ runtime เฉพาะสิทธิ์ที่จำเป็น รวม SELECT/INSERT บน ledger และไม่มี DDL ใบสั่งซื้ออ้างถึงผู้ใช้ในตาราง users ของบริการนี้ การเชื่อม LINE หรือ Supabase Auth ต้องเพิ่มตัวแปลง identity เข้ากับ users.id

## โครงสร้าง

~~~text
app/
  __init__.py
  main.py          REST controllers, CSV streaming, error handlers
  auth.py          ตรวจ Bearer token และ RBAC จากฐานข้อมูล
  db.py            connection pool และ transaction scope
  models.py        Pydantic request schemas
  services.py      pricing, reservation, payment review, SLA, refund
  workers.py       งานคืนสต็อกและชดเชย SLA
  manage.py        migration, seed และออก token
migrations/001_commerce.sql
scripts/demo.py
tests/conftest.py
tests/test_flow.py
.env.example
.dockerignore
Dockerfile
compose.yaml
requirements.txt
requirements-test.txt
openapi.json
README.md
~~~

## สัญญา API

ส่ง JSON และ Authorization: Bearer <token> สำหรับเส้นทางที่ต้องล็อกอิน ตัวเลขการเงินใน request ส่งเป็น decimal string ได้ จำนวนชิ้นต้องเป็นจำนวนเต็ม ผลลัพธ์รายรายการคืน JSON object รายการแบบแบ่งหน้าคืน array ส่ง page และ page_size ได้ (1–100 ต่อหน้า)

| Method และ path | ผู้ใช้ | Input หรือพฤติกรรม |
|---|---|---|
| GET /api/products | ทุกคน | search, category, origin_hub, cold_chain, page, page_size คืนสินค้าที่เปิดขายและ variants |
| GET /api/media-posts | ทุกคน | คลิปพร้อม product_id ชื่อสินค้า หมวดหมู่ และสถานะ live |
| POST /api/vouchers/validate | ทุกคน | Basket แบบเดียวกับสร้างออเดอร์ คืนราคา ส่วนลด ค่าส่ง due_now และ remaining_after_first |
| POST /api/checkin | สมาชิก | ไม่มี body คืน awarded และ points_balance |
| POST /api/orders | สมาชิก | Basket + header Idempotency-Key UUID คืน order_no, grand_total, balance_due, due_now และเวลาหมดจอง |
| GET /api/orders | สมาชิก | เฉพาะรายการของตน |
| GET /api/orders/{number} | เจ้าของออเดอร์ | ออเดอร์ รายการ สลิป ขนส่ง ยอดคงค้าง SLA |
| POST /api/orders/{number}/payments | เจ้าของออเดอร์ | payment_stage, amount, slip_image_url, transfer_ref คืน payment ID และสถานะ pending |
| POST /api/orders/{number}/cancel | เจ้าของออเดอร์ | ยกเลิกก่อนยืนยันงวดแรกและคืนของ/โควต้า |
| GET /api/ledger และ /api/notifications | สมาชิก | รายการเดินบัญชีหรือแจ้งเตือนของตนเอง |
| GET /api/admin/dashboard | staff/admin | gross_sales, net_receipts, outstanding, awaiting_verification, near_sla |
| GET /api/admin/payments | staff/admin | คิวสลิปรอตรวจพร้อมเลขออเดอร์ |
| PATCH /api/admin/payments/{pid}/verify | admin | decision เป็น approved หรือ rejected ถ้าปฏิเสธต้องส่ง reject_reason |
| POST /api/admin/orders/{number}/ship | staff/admin | carrier_name และ tracking_no |
| POST /api/admin/orders/{number}/deliver | staff/admin | ยืนยันส่งถึง ณ เวลาเซิร์ฟเวอร์ ตรวจชดเชยทันทีถ้าล่าช้า |
| POST /api/admin/orders/{number}/sla-compensate | staff/admin | ไม่ต้องส่ง body คืน awarded เท่ากับ 50 หรือ 0 เมื่อเคยได้แล้ว |
| POST /api/admin/orders/{number}/refund | admin | ลงบัญชีคืนเต็มจำนวนเงินที่รับแล้ว หลังผู้ดูแลดำเนินการโอนคืน ไม่คืนสต็อกสินค้าที่ยังไม่ได้รับกลับ |
| POST /api/admin/products | admin | ข้อมูลสินค้าและ variants อย่างน้อยหนึ่งรายการ บันทึกพร้อมกัน |
| PATCH /api/admin/variants/{vid}/stock | staff/admin | expected_available และ stock_available กันการเขียนทับสต็อกเก่า |
| GET /api/admin/ledger/export | admin | CSV UTF-8 BOM อ่านเป็นชุดผ่าน server cursor |

ข้อผิดพลาดคืน detail เช่น INSUFFICIENT_STOCK, QUOTA_EXHAUSTED หรือ RESERVATION_EXPIRED ใช้ 401 เมื่อไม่มี token/หมดอายุ, 403 บทบาทไม่อนุญาต, 404 เมื่อไม่พบหรือออเดอร์คนอื่น, 409 เมื่อสถานะ/สต็อกขัดแย้ง, 422 สำหรับ input หรือเงื่อนไขราคา หากได้ RETRY_TRANSACTION ให้ส่งทั้งคำขอใหม่โดยใช้ Idempotency-Key หรือ transfer_ref เดิม

## นโยบายและสถานะ

- ราคาส่งพิจารณาจำนวนต่อ SKU ใช้ได้ทั้งลูกค้าปลีกและขายส่ง ไม่รับราคาจาก client การสร้าง order ล็อกสิทธิ์คูปองและแถว SKU ตาม UUID ก่อนคำนวณราคาซ้ำ ภายใน transaction เดียวจึงย้าย available → reserved ได้พร้อมใช้โควต้าหนึ่งสิทธิ์
- ค่าส่งตัวอย่าง 40 บาท ฟรีเมื่อยอดสินค้าก่อนลดถึง 1,500 บาท ค่า weight_grams และ cold chain เป็นข้อมูลสินค้า ไม่คิด surcharge ในเรทตัวอย่างนี้
- หนึ่งโค้ดต่อออเดอร์ fixed ลดไม่เกินค่าสินค้า percent ปัดครึ่งขึ้นที่สตางค์ free_shipping ยกเว้นค่าส่งทั้งหมด ยอดขั้นต่ำดูจาก subtotal โควต้าของใบจองที่ยกเลิกคืนได้
- หากไม่ระบุ payment_mode และมี SKU require_deposit_pct=50 เลือก deposit_50 ให้อัตโนมัติ ร้านยอมให้จ่ายเต็มแทนได้ ลูกค้าเลือกมัดจำ 50% ได้ในตะกร้าทั่วไป มัดจำคิดจาก grand_total รวมค่าส่งหลังลด ยอดค้างก่อนจ่ายคือเต็ม grand_total และลดลงเฉพาะเมื่ออนุมัติสลิป
- เก็บสลิปเป็น URL ที่ caller อัปโหลดไป object storage ไว้ก่อน แอดมินตรวจหลักฐานด้วยตนเอง API ไม่ดึง URL มาตรวจแทนธนาคาร และไม่โอนเงินจริง transfer_ref ต้องไม่ซ้ำกับใบโอนอื่น การอนุมัติซ้ำไม่เพิ่มยอด
- pending_payment → verifying_slip → deposit_paid/paid หลังอนุมัติครั้งแรกตัด reserved และเริ่ม SLA ปฏิเสธสลิปแรกกลับไปรอชำระ การรับยอดคงเหลือระหว่างขนส่งรักษาสถานะขนส่งไว้ จองหมดอายุใน 30 นาทีรวมเวลารอตรวจสลิป กรณีเงินเข้าแล้วแต่ตรวจไม่ทัน ให้ร้านกระทบยอดและคืนเงินหรือเปิดออเดอร์ใหม่
- แบบจำลองใช้หนึ่ง shipment ต่อออเดอร์ SLA จากเวลายืนยันงวดแรกบวก SLA ยาวสุดของทุก SKU หน่วยชั่วโมงตามจริง กรณีต้นทางหลายแห่งเก็บรายชื่อ hub ใน snapshot งาน delivery ลง delivered_at ตามเวลาเซิร์ฟเวอร์
- ReleaseExpiredReservationsJob ทำงานทุก 60 วินาที SlaBreachMonitorJob ทุก 900 วินาที ทั้งคู่เริ่มประมวลผลเมื่อเปิด worker ใช้ FOR UPDATE SKIP LOCKED และ commit ทีละออเดอร์ เปิด worker หลายตัวได้ การชดเชยตรวจ flag พร้อม event_key เฉพาะออเดอร์ ได้ 50 แต้มหนึ่งครั้งและสร้างข้อความใน /api/notifications ชดเชยได้แม้ยังไม่ส่งออกจากคลัง
- เช็กอิน 10 แต้มต่อวันไทย รับซื้อทุก 100 บาทที่อนุมัติสะสมต่อออเดอร์ได้ 1 แต้ม จ่ายมัดจำและยอดค้างรวมกันก่อนปัดคะแนน คืนเงินบันทึกแถวติดลบพร้อมย้อนแต้มจากการซื้อ ยอดรับจริงในแดชบอร์ดหัก refund แล้ว ส่วน paid_amount เก็บยอดที่เคยรับจริง ประวัติ ledger ป้องกัน UPDATE/DELETE/TRUNCATE
- gross_sales รวมออเดอร์ที่ยืนยันแล้วและยังไม่คืนเงิน outstanding รวมคงค้างของออเดอร์ที่ยืนยันแล้ว near_sla คือใกล้ถึงกำหนดภายใน 6 ชั่วโมง เก็บ affiliate_id เพื่อระบุที่มา schema รองรับชนิด affiliate_commission แต่รอบจ่ายพาร์ตเนอร์และการถอนเครดิตอยู่นอกชุด endpoint นี้
- CLI ออก token ใช้ได้ 12 ชั่วโมง เก็บ SHA-256 digest ใน DB และอ่าน role ปัจจุบันทุกคำขอ ใช้เฉพาะ CLI ฝั่งผู้ดูแลสำหรับออก token ทดสอบ ข้อมูล seed ไม่ใช่ข้อมูลลูกค้าจริง

## ตัวอย่างทดสอบผ่าน HTTP

scripts/demo.py จอง 3 ชิ้นที่ราคาส่ง 690 บาท ยอดสินค้า 2,070 บาท ฟรีค่าส่ง ใช้ SAVE10 ลด 207 บาท รวม 1,863 บาท มัดจำ 931.50 บาท ยอดค้าง 931.50 บาทเมื่ออนุมัติงวดแรก และ 0 หลังอนุมัติงวดสุดท้าย ตัวอย่าง endpoint ตรวจสลิป:

~~~bash
curl -X PATCH "http://localhost:8000/api/admin/payments/$PAYMENT_ID/verify" \
  -H "Authorization: Bearer $ADMIN_TOKEN" -H 'Content-Type: application/json' \
  -d '{"decision":"approved"}'
~~~

ทดสอบ SLA ทันทีโดยใช้ฐาน **ทดสอบเท่านั้น** ตั้ง ORDER_NO จาก output ของ demo แล้วเลื่อนกำหนดของออเดอร์ทดสอบให้ผ่านไปแล้ว งาน worker อาจให้แต้มก่อนคำขอแรก จึงตรวจผลรวมจาก ledger และ notification ได้ด้วย

~~~bash
docker compose exec -T db sh -c 'psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -v ON_ERROR_STOP=1 -v ord="$1"' sh "$ORDER_NO" <<'SQL'
UPDATE orders SET promised_delivery_at=now()-interval '1 minute'
WHERE order_no=:'ord' AND committed AND delivered_at IS NULL;
SQL
curl -X POST -H "Authorization: Bearer $ADMIN_TOKEN" "http://localhost:8000/api/admin/orders/$ORDER_NO/sla-compensate"
curl -X POST -H "Authorization: Bearer $ADMIN_TOKEN" "http://localhost:8000/api/admin/orders/$ORDER_NO/sla-compensate"
curl -H "Authorization: Bearer $BUYER_TOKEN" http://localhost:8000/api/notifications
~~~

## รัน integration tests

ใช้ PostgreSQL ทดสอบแยก ให้บัญชีทดสอบสร้าง schema ได้ tests สร้างชื่อ schema แบบสุ่มและลบเฉพาะ schema นั้นเมื่อจบ

~~~bash
source .venv/bin/activate
pip install -r requirements-test.txt
export TEST_DATABASE_URL='postgresql://kram:kram_local_change_me@localhost:5432/kram'
python -m pytest -q
~~~

ชุดทดสอบใช้ HTTP ผ่าน FastAPI TestClient และ PostgreSQL จริง ครอบคลุมการแย่งสต็อกชิ้นสุดท้ายและคูปองสิทธิ์สุดท้าย, การคืนจองซ้ำ, การจ่ายเต็ม/มัดจำ, การปฏิเสธและอนุมัติสลิปซ้ำ, การยืนยันหลังหมดอายุ, การคืนเงิน, การชดเชยหลาย worker, การส่งถึงภายใน SLA, RBAC, CSV และการป้องกันแก้ไข ledger
