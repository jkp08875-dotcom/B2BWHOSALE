import hashlib
from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from .db import transaction, one


def connection():
    with transaction() as db:
        yield db


def current(
    token: HTTPAuthorizationCredentials | None = Depends(HTTPBearer(auto_error=False)),
    db=Depends(connection),
):
    if token:
        digest = hashlib.sha256(token.credentials.encode()).hexdigest()
        user = one(
            db,
            "SELECT u.id,u.role FROM api_tokens t JOIN users u ON u.id=t.user_id WHERE digest=%s AND expires_at>now()",
            (digest,),
        )
        if user:
            return user
    raise HTTPException(401, "AUTH_REQUIRED", headers={"WWW-Authenticate": "Bearer"})


def staff(user=Depends(current)):
    if user["role"] not in ("staff", "admin"):
        raise HTTPException(403, "STAFF_REQUIRED")
    return user


def admin(user=Depends(current)):
    if user["role"] != "admin":
        raise HTTPException(403, "ADMIN_REQUIRED")
    return user
