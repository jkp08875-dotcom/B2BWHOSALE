import logging
import time
from .db import transaction, pool, one
from .services import cancel, compensate


def release_expired_reservations_job():
    return drain(
        """SELECT * FROM orders WHERE NOT committed AND status IN ('pending_payment','verifying_slip')
       AND expires_at<=clock_timestamp() ORDER BY expires_at,id LIMIT 1 FOR UPDATE SKIP LOCKED""",
        cancel,
    )


def sla_breach_monitor_job():
    return drain(
        """SELECT o.* FROM orders o JOIN shipments s ON s.order_id=o.id WHERE o.committed
      AND o.status NOT IN ('cancelled','refunded') AND NOT s.sla_compensated AND o.promised_delivery_at<clock_timestamp()
      AND (o.delivered_at IS NULL OR o.delivered_at>o.promised_delivery_at)
      ORDER BY o.promised_delivery_at,o.id LIMIT 1 FOR UPDATE OF o SKIP LOCKED""",
        compensate,
    )


def drain(query, handle):
    count = 0
    while True:
        with transaction() as db:
            o = one(db, query)
            if not o:
                return count
            handle(db, o)
        count += 1


def main():
    from concurrent.futures import ThreadPoolExecutor

    def periodic(job, seconds):
        while True:
            start = time.monotonic()
            try:
                job()
            except Exception:
                logging.exception("Job failed: %s", job.__name__)
            time.sleep(max(1, seconds - time.monotonic() + start))

    pool.open()
    with ThreadPoolExecutor(max_workers=2) as workers:
        workers.submit(periodic, release_expired_reservations_job, 60)
        workers.submit(periodic, sla_breach_monitor_job, 900)


if __name__ == "__main__":
    main()
