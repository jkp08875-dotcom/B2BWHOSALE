from decimal import Decimal
from typing import Annotated, Literal
from uuid import UUID
from pydantic import BaseModel, Field, ConfigDict, HttpUrl, model_validator


class Input(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


Text = Annotated[str, Field(min_length=1, max_length=200)]
Price = Annotated[Decimal, Field(gt=0, max_digits=12, decimal_places=2)]


class Line(Input):
    variant_id: UUID
    qty: int = Field(ge=1, le=10000, strict=True)


class Basket(Input):
    lines: list[Line] = Field(min_length=1, max_length=80)
    voucher_code: Text | None = None
    payment_mode: Literal["full", "deposit_50"] | None = None
    affiliate_id: UUID | None = None

    @model_validator(mode="after")
    def unique_lines(self):
        if len({line.variant_id for line in self.lines}) != len(self.lines):
            raise ValueError("duplicate variant")
        return self


class Slip(Input):
    payment_stage: Literal["full", "deposit", "balance"]
    amount: Price
    slip_image_url: HttpUrl
    transfer_ref: Text


class Decision(Input):
    decision: Literal["approved", "rejected"]
    reject_reason: Text | None = None

    @model_validator(mode="after")
    def reason(self):
        if self.decision == "rejected" and not self.reject_reason:
            raise ValueError("reject_reason required")
        return self


class Ship(Input):
    carrier_name: Text
    tracking_no: Text


class Stock(Input):
    expected_available: int = Field(ge=0, le=2_000_000_000)
    stock_available: int = Field(ge=0, le=2_000_000_000)


class Variant(Input):
    sku: Text
    variant_name: Text
    retail_price: Price
    wholesale_price: Price
    wholesale_min_qty: int = Field(ge=1, le=10000)
    stock_available: int = Field(ge=0, le=2_000_000_000)
    require_deposit_pct: Literal[0, 50] = 0
    weight_grams: int = Field(ge=1, le=1000000)

    @model_validator(mode="after")
    def wholesale(self):
        if self.wholesale_price > self.retail_price:
            raise ValueError("invalid wholesale price")
        return self


class Product(Input):
    title: Text
    description: str = Field(default="", max_length=5000)
    category: Text
    origin_hub: Text
    sla_delivery_hours: int = Field(ge=1, le=8760)
    is_cold_chain: bool = False
    status: Literal["active", "inactive", "archived"] = "active"
    variants: list[Variant] = Field(min_length=1, max_length=100)
