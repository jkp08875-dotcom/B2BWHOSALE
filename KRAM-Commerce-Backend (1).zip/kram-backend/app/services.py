"""All mutations run inside the caller's transaction; lock order: order, voucher, sorted SKUs."""

import hashlib
import json
from decimal import Decimal, ROUND_HALF_UP
from uuid import uuid4
from fastapi import HTTPException
from .db import one, rows


def require(ok, code, status=409):
    if not ok:
        raise HTTPException(status, code)


def money(value):
    return Decimal(value).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def now(db):
    return one(db, "SELECT clock_timestamp() AS t")["t"]


def order(db, number, buyer=None, lock=True):
    sql = "SELECT * FROM orders WHERE order_no=%s"
    args = [number]
    if buyer is not None:
        sql += " AND user_id=%s"
        args.append(buyer)
    result = one(db, sql + (" FOR UPDATE" if lock else ""), args)
    require(result, "ORDER_NOT_FOUND", 404)
    return result


def estimate(db, basket, hold=False):
    voucher = None
    if basket.voucher_code:
        voucher = one(
            db,
            "SELECT * FROM vouchers WHERE code=%s" + (" FOR UPDATE" if hold else ""),
            (basket.voucher_code.upper(),),
        )
        require(voucher and voucher["is_active"], "VOUCHER_INACTIVE", 422)
    qty = {x.variant_id: x.qty for x in basket.lines}
    items = rows(
        db,
        """SELECT v.*,p.title,p.origin_hub,p.sla_delivery_hours,p.is_cold_chain FROM product_variants v
      JOIN products p ON p.id=v.product_id WHERE p.status='active' AND v.id=ANY(%s)
      ORDER BY v.id"""
        + (" FOR UPDATE OF v FOR SHARE OF p" if hold else ""),
        (list(qty),),
    )
    require(len(items) == len(qty), "VARIANT_NOT_AVAILABLE", 422)
    goods = Decimal(0)
    for v in items:
        n = qty[v["id"]]
        require(n <= v["stock_available"], "INSUFFICIENT_STOCK")
        v["qty"] = n
        v["price"] = (
            v["wholesale_price"] if n >= v["wholesale_min_qty"] else v["retail_price"]
        )
        goods += v["price"] * n
    ship = Decimal(0 if goods >= 1500 else 40)
    discount = Decimal(0)
    if voucher:
        require(voucher["expires_at"] > now(db), "VOUCHER_EXPIRED", 422)
        require(goods >= voucher["min_spend"], "MIN_SPEND", 422)
        require(voucher["used_quota"] < voucher["max_quota"], "QUOTA_EXHAUSTED")
        kind, value = voucher["discount_type"], voucher["discount_value"]
        discount = (
            ship
            if kind == "free_shipping"
            else min(goods, value)
            if kind == "fixed"
            else money(goods * value / 100)
        )
    total = goods + ship - discount
    mode = basket.payment_mode or (
        "deposit_50" if any(i["require_deposit_pct"] == 50 for i in items) else "full"
    )
    # A deposit-enabled item requires at least 50%. Paying 100% also satisfies it.
    first = money(total / 2) if mode == "deposit_50" else total
    quote = dict(
        subtotal=goods,
        shipping_fee=ship,
        discount_amount=discount,
        grand_total=total,
        due_now=first,
        remaining_after_first=total - first,
        payment_mode=mode,
        minimum_deposit_pct=max(v["require_deposit_pct"] for v in items),
    )
    return quote, items, voucher


def stock_transition(db, oid, action):
    lines = rows(
        db,
        "SELECT variant_id,qty FROM order_items WHERE order_id=%s ORDER BY variant_id",
        (oid,),
    )
    for x in lines:
        n = x["qty"]
        if action == "reserve":
            db.execute(
                "UPDATE product_variants SET stock_available=stock_available-%s,stock_reserved=stock_reserved+%s WHERE id=%s",
                (n, n, x["variant_id"]),
            )
        else:
            db.execute(
                "UPDATE product_variants SET stock_reserved=stock_reserved-%s,stock_available=stock_available+%s WHERE id=%s",
                (n, n if action == "release" else 0, x["variant_id"]),
            )


def commit_hold(db, o):
    stock_transition(db, o["id"], "commit")
    db.execute(
        """UPDATE orders SET committed=true,promised_delivery_at=clock_timestamp()+sla_hours*interval '1 hour'
                  WHERE id=%s""",
        (o["id"],),
    )
    db.execute(
        "INSERT INTO shipments(order_id,origin_hub) VALUES(%s,%s)",
        (o["id"], o["origin_snapshot"]),
    )


def create_order(db, buyer, key, basket):
    payload = basket.model_dump(mode="json")
    payload["lines"].sort(key=lambda line: line["variant_id"])
    digest = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
    db.execute(
        "SELECT pg_advisory_xact_lock(hashtextextended(%s,0))", (str(buyer) + str(key),)
    )
    prev = one(
        db, "SELECT * FROM orders WHERE user_id=%s AND request_key=%s", (buyer, key)
    )
    if prev:
        require(prev["request_hash"] == digest, "KEY_REUSED")
        return prev
    if basket.affiliate_id:
        require(
            buyer != basket.affiliate_id
            and one(
                db,
                "SELECT 1 FROM users WHERE id=%s AND role='affiliate'",
                (basket.affiliate_id,),
            ),
            "INVALID_AFFILIATE",
            422,
        )
    q, items, v = estimate(db, basket, True)
    if v:
        db.execute(
            "UPDATE vouchers SET used_quota=used_quota+1 WHERE id=%s", (v["id"],)
        )
    o = one(
        db,
        """INSERT INTO orders(order_no,user_id,affiliate_id,voucher_id,status,payment_mode,subtotal,shipping_fee,
       discount_amount,expires_at,sla_hours,origin_snapshot,request_key,request_hash)
       VALUES(%s,%s,%s,%s,'pending_payment',%s,%s,%s,%s,clock_timestamp()+interval '30 minutes',%s,%s,%s,%s) RETURNING *""",
        (
            "KR-" + uuid4().hex.upper(),
            buyer,
            basket.affiliate_id,
            v["id"] if v else None,
            q["payment_mode"],
            q["subtotal"],
            q["shipping_fee"],
            q["discount_amount"],
            max(i["sla_delivery_hours"] for i in items),
            ", ".join(sorted({i["origin_hub"] for i in items})),
            key,
            digest,
        ),
    )
    for i in items:
        db.execute(
            "INSERT INTO order_items(order_id,variant_id,sku_snapshot,title_snapshot,qty,unit_price) VALUES(%s,%s,%s,%s,%s,%s)",
            (
                o["id"],
                i["id"],
                i["sku"],
                i["title"] + " · " + i["variant_name"],
                i["qty"],
                i["price"],
            ),
        )
    stock_transition(db, o["id"], "reserve")
    if q["grand_total"] == 0:
        commit_hold(db, o)
        db.execute("UPDATE orders SET status='paid' WHERE id=%s", (o["id"],))
    return order(db, o["order_no"], buyer, False)


def cancel(db, o):
    if o["status"] == "cancelled":
        return
    require(not o["committed"], "ALREADY_CONFIRMED")
    if o["voucher_id"]:
        db.execute(
            "UPDATE vouchers SET used_quota=used_quota-1 WHERE id=%s",
            (o["voucher_id"],),
        )
    stock_transition(db, o["id"], "release")
    db.execute("UPDATE orders SET status='cancelled' WHERE id=%s", (o["id"],))
    db.execute(
        "UPDATE payments SET status='rejected',verified_at=clock_timestamp(),reject_reason='reservation cancelled' WHERE order_id=%s AND status='pending'",
        (o["id"],),
    )


def expected(db, o):
    require(
        o["status"] not in ("refunded", "cancelled") and o["balance_due"] > 0,
        "NO_BALANCE",
    )
    if o["committed"]:
        return "balance", o["balance_due"]
    require(o["expires_at"] > now(db), "RESERVATION_EXPIRED")
    return (
        ("deposit", money(o["grand_total"] / 2))
        if o["payment_mode"] == "deposit_50"
        else ("full", o["grand_total"])
    )


def submit_slip(db, o, b):
    prev = one(db, "SELECT * FROM payments WHERE transfer_ref=%s", (b.transfer_ref,))
    if prev:
        require(
            prev["order_id"] == o["id"]
            and prev["amount"] == b.amount
            and prev["slip_image_url"] == str(b.slip_image_url)
            and prev["payment_stage"] == b.payment_stage,
            "TRANSFER_REF_USED",
        )
        return prev
    require(
        expected(db, o) == (b.payment_stage, b.amount), "WRONG_STAGE_OR_AMOUNT", 422
    )
    p = one(
        db,
        "INSERT INTO payments(order_id,payment_stage,amount,slip_image_url,transfer_ref) VALUES(%s,%s,%s,%s,%s) RETURNING *",
        (o["id"], b.payment_stage, b.amount, str(b.slip_image_url), b.transfer_ref),
    )
    if not o["committed"]:
        db.execute("UPDATE orders SET status='verifying_slip' WHERE id=%s", (o["id"],))
    return p


def entry(db, uid, oid, kind, amount, points, key, note):
    return one(
        db,
        """INSERT INTO ledger_entries(user_id,order_id,entry_type,amount_delta,points_delta,event_key,reference_note)
         VALUES(%s,%s,%s,%s,%s,%s,%s) ON CONFLICT(event_key) DO NOTHING RETURNING id""",
        (uid, oid, kind, amount, points, key, note),
    )


def verify(db, pid, b, staff):
    o = one(
        db,
        "SELECT o.* FROM orders o JOIN payments p ON p.order_id=o.id WHERE p.id=%s FOR UPDATE OF o",
        (pid,),
    )
    require(o, "PAYMENT_NOT_FOUND", 404)
    p = one(db, "SELECT * FROM payments WHERE id=%s FOR UPDATE", (pid,))
    if p["status"] == b.decision:
        return p
    require(p["status"] == "pending", "ALREADY_REVIEWED")
    if b.decision == "approved":
        stage, amount = expected(db, o)
        require(
            (stage, amount) == (p["payment_stage"], p["amount"]), "PAYMENT_MISMATCH"
        )
        if not o["committed"]:
            commit_hold(db, o)
        received = o["paid_amount"] + amount
        status = "paid" if received == o["grand_total"] else "deposit_paid"
        if o["status"] in ("packing", "shipped", "delayed", "delivered"):
            status = o["status"]
        db.execute(
            "UPDATE orders SET paid_amount=%s,status=%s WHERE id=%s",
            (received, status, o["id"]),
        )
        kind = {
            "full": "order_payment",
            "deposit": "deposit_payment",
            "balance": "balance_payment",
        }[stage]
        points = int(received // 100) - int(o["paid_amount"] // 100)
        entry(
            db,
            o["user_id"],
            o["id"],
            kind,
            amount,
            points,
            "receipt:" + str(pid),
            p["transfer_ref"],
        )
    elif not o["committed"]:
        db.execute("UPDATE orders SET status='pending_payment' WHERE id=%s", (o["id"],))
    return one(
        db,
        "UPDATE payments SET status=%s,verified_by=%s,verified_at=clock_timestamp(),reject_reason=%s WHERE id=%s RETURNING *",
        (b.decision, staff, b.reject_reason if b.decision == "rejected" else None, pid),
    )


def compensate(db, o):
    require(
        o["committed"] and o["status"] not in ("refunded", "cancelled"),
        "ORDER_NOT_ELIGIBLE",
    )
    shipment = one(
        db, "SELECT * FROM shipments WHERE order_id=%s FOR UPDATE", (o["id"],)
    )
    if shipment["sla_compensated"]:
        return False
    require(
        (o["delivered_at"] or now(db)) > o["promised_delivery_at"], "SLA_NOT_BREACHED"
    )
    entry(
        db,
        o["user_id"],
        o["id"],
        "sla_compensation",
        0,
        50,
        "sla:" + str(o["id"]),
        "ส่งถึงเกินกำหนด SLA",
    )
    db.execute(
        "UPDATE shipments SET sla_compensated=true WHERE order_id=%s", (o["id"],)
    )
    if not o["delivered_at"]:
        db.execute("UPDATE orders SET status='delayed' WHERE id=%s", (o["id"],))
    db.execute(
        "INSERT INTO notifications(user_id,order_id,message) VALUES(%s,%s,%s)",
        (o["user_id"], o["id"], "ส่งล่าช้า ร้านเพิ่มแต้มชดเชย 50 แต้มแล้ว"),
    )
    return True


def refund(db, o):
    if o["status"] == "refunded":
        return
    require(o["paid_amount"] > 0 and o["committed"], "NOT_REFUNDABLE")
    entry(
        db,
        o["user_id"],
        o["id"],
        "refund",
        -o["paid_amount"],
        -int(o["paid_amount"] // 100),
        "refund:" + str(o["id"]),
        "บันทึกคืนเงินเต็มจำนวน",
    )
    db.execute("UPDATE orders SET status='refunded' WHERE id=%s", (o["id"],))
    db.execute(
        "UPDATE payments SET status='rejected',verified_at=now(),reject_reason='order refunded' WHERE order_id=%s AND status='pending'",
        (o["id"],),
    )
