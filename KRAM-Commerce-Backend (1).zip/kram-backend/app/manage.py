"""python -m app.manage migrate | seed | token PHONE"""

import hashlib
import secrets
import sys
from pathlib import Path
from .db import pool, transaction, one


def migrate(db):
    db.execute("SELECT pg_advisory_xact_lock(7259081)")
    db.execute(
        "CREATE TABLE IF NOT EXISTS schema_migrations(name text PRIMARY KEY, sha text NOT NULL)"
    )
    for path in sorted(
        (Path(__file__).resolve().parents[1] / "migrations").glob("*.sql")
    ):
        content = path.read_bytes()
        digest = hashlib.sha256(content).hexdigest()
        old = one(db, "SELECT sha FROM schema_migrations WHERE name=%s", (path.name,))
        if old and old["sha"] != digest:
            raise RuntimeError("Changed migration " + path.name)
        if not old:
            db.execute(content.decode())
            db.execute(
                "INSERT INTO schema_migrations VALUES(%s,%s)", (path.name, digest)
            )


def seed(db):
    for phone, name, role in [
        ("0800000001", "ลูกค้าทดสอบ", "customer"),
        ("0800000002", "เจ้าของร้านทดสอบ", "admin"),
        ("0800000003", "คลังทดสอบ", "staff"),
    ]:
        db.execute(
            "INSERT INTO users(full_name,phone,role) VALUES(%s,%s,%s) ON CONFLICT(phone) DO NOTHING",
            (name, phone, role),
        )
    pid = "10000000-0000-4000-8000-000000000001"
    db.execute(
        """INSERT INTO products(id,title,category,origin_hub,sla_delivery_hours,status)
      VALUES(%s,'หูฟัง KRAM','เครื่องเสียง','เชียงใหม่',48,'active') ON CONFLICT DO NOTHING""",
        (pid,),
    )
    db.execute(
        """INSERT INTO product_variants(id,product_id,sku,variant_name,retail_price,wholesale_price,
      wholesale_min_qty,stock_available,require_deposit_pct,weight_grams)
      VALUES('20000000-0000-4000-8000-000000000001',%s,'KR-H01','สีดำ',890,690,3,100,50,250) ON CONFLICT DO NOTHING""",
        (pid,),
    )
    db.execute(
        """INSERT INTO media_posts(id,product_id,type,title,media_url,thumbnail_url)
      VALUES('30000000-0000-4000-8000-000000000001',%s,'short_video','รีวิวหูฟัง','https://example.com/review.mp4','https://example.com/cover.jpg') ON CONFLICT DO NOTHING""",
        (pid,),
    )
    db.execute("""INSERT INTO vouchers(code,discount_type,discount_value,min_spend,max_quota,expires_at)
      VALUES('SAVE10','percent',10,500,100,now()+interval '90 days') ON CONFLICT DO NOTHING""")


def token(db, phone):
    user = one(db, "SELECT id FROM users WHERE phone=%s", (phone,))
    if not user:
        raise ValueError("Unknown phone")
    raw = secrets.token_urlsafe(32)
    db.execute(
        "INSERT INTO api_tokens VALUES(%s,%s,now()+interval '12 hours')",
        (hashlib.sha256(raw.encode()).hexdigest(), user["id"]),
    )
    return raw


if __name__ == "__main__":
    pool.open()
    try:
        with transaction() as db:
            if sys.argv[1:] == ["migrate"]:
                migrate(db)
            elif sys.argv[1:] == ["seed"]:
                seed(db)
            elif len(sys.argv) == 3 and sys.argv[1] == "token":
                print(token(db, sys.argv[2]))
            else:
                raise SystemExit(
                    "Usage: python -m app.manage migrate | seed | token PHONE"
                )
    finally:
        pool.close()
