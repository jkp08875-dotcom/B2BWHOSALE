import csv
from contextlib import asynccontextmanager
from io import StringIO
from uuid import UUID
from fastapi import FastAPI, Depends, Header, Query, Response
from fastapi.responses import JSONResponse, StreamingResponse
from psycopg import IntegrityError, errors
from .db import pool, one, rows, transaction
from .auth import connection, current, admin, staff
from . import services as svc
from .models import Basket, Slip, Decision, Ship, Product, Stock


@asynccontextmanager
async def lifespan(app):
    pool.open()
    yield
    pool.close()


app = FastAPI(title="KRAM Commerce API", version="1.0", lifespan=lifespan)


@app.exception_handler(IntegrityError)
def constraint_error(req, exc):
    return JSONResponse(status_code=409, content={"detail": "DATA_CONFLICT"})


@app.exception_handler(errors.DeadlockDetected)
@app.exception_handler(errors.SerializationFailure)
def retry_conflict(req, exc):
    return JSONResponse(status_code=409, content={"detail": "RETRY_TRANSACTION"})


def paging(
    page: int = Query(1, ge=1, le=100000), page_size: int = Query(20, ge=1, le=100)
):
    return page_size, (page - 1) * page_size


@app.get("/api/products")
def products(
    search: str = "",
    category: str | None = None,
    origin_hub: str | None = None,
    cold_chain: bool | None = None,
    pg=Depends(paging),
    db=Depends(connection),
):
    where = ["p.status='active'"]
    args = []
    for column, value in [
        ("category", category),
        ("origin_hub", origin_hub),
        ("is_cold_chain", cold_chain),
    ]:
        if value is not None:
            where.append("p." + column + "=%s")
            args.append(value)
    if search:
        where.append("position(lower(%s) in lower(p.title))>0")
        args.append(search)
    result = rows(
        db,
        "SELECT p.* FROM products p WHERE "
        + " AND ".join(where)
        + " ORDER BY p.created_at DESC,p.id LIMIT %s OFFSET %s",
        (*args, *pg),
    )
    variants = (
        rows(
            db,
            "SELECT * FROM product_variants WHERE product_id=ANY(%s) ORDER BY sku",
            ([p["id"] for p in result],),
        )
        if result
        else []
    )
    for p in result:
        p["variants"] = [v for v in variants if v["product_id"] == p["id"]]
    return result


@app.get("/api/media-posts")
def media(pg=Depends(paging), db=Depends(connection)):
    return rows(
        db,
        "SELECT m.*,p.title AS product_title,p.category FROM media_posts m JOIN products p ON m.product_id=p.id WHERE p.status='active' ORDER BY m.is_live DESC,m.created_at DESC,m.id LIMIT %s OFFSET %s",
        pg,
    )


@app.post("/api/vouchers/validate")
def quote(b: Basket, db=Depends(connection)):
    return svc.estimate(db, b)[0]


@app.post("/api/checkin")
def checkin(u=Depends(current), db=Depends(connection)):
    day = one(db, "SELECT (now() AT TIME ZONE 'Asia/Bangkok')::date AS d")["d"]
    result = svc.entry(
        db,
        u["id"],
        None,
        "points_checkin",
        0,
        10,
        f"checkin:{u['id']}:{day}",
        "เช็กอินรายวัน",
    )
    return {
        "awarded": 10 if result else 0,
        **one(db, "SELECT points_balance FROM users WHERE id=%s", (u["id"],)),
    }


@app.post("/api/orders", status_code=201)
def checkout(
    b: Basket,
    key: UUID = Header(alias="Idempotency-Key"),
    u=Depends(current),
    db=Depends(connection),
):
    o = svc.create_order(db, u["id"], key, b)
    if o["committed"] or o["status"] == "cancelled":
        due = o["balance_due"]
    else:
        due = (
            svc.money(o["grand_total"] / 2)
            if o["payment_mode"] == "deposit_50"
            else o["grand_total"]
        )
    return {**o, "due_now": due}


@app.get("/api/orders")
def orders(u=Depends(current), pg=Depends(paging), db=Depends(connection)):
    return rows(
        db,
        "SELECT * FROM orders WHERE user_id=%s ORDER BY created_at DESC,id LIMIT %s OFFSET %s",
        (u["id"], *pg),
    )


@app.get("/api/orders/{number}")
def detail(number: str, u=Depends(current), db=Depends(connection)):
    o = svc.order(db, number, u["id"], False)
    return {
        **o,
        "items": rows(db, "SELECT * FROM order_items WHERE order_id=%s", (o["id"],)),
        "payments": rows(
            db,
            "SELECT * FROM payments WHERE order_id=%s ORDER BY created_at",
            (o["id"],),
        ),
        "shipment": one(db, "SELECT * FROM shipments WHERE order_id=%s", (o["id"],)),
    }


@app.post("/api/orders/{number}/cancel")
def cancel(number: str, u=Depends(current), db=Depends(connection)):
    svc.cancel(db, svc.order(db, number, u["id"]))
    return {"status": "cancelled"}


@app.post("/api/orders/{number}/payments", status_code=201)
def payment(number: str, b: Slip, u=Depends(current), db=Depends(connection)):
    return svc.submit_slip(db, svc.order(db, number, u["id"]), b)


@app.get("/api/ledger")
def ledger(u=Depends(current), db=Depends(connection), pg=Depends(paging)):
    return rows(
        db,
        "SELECT * FROM ledger_entries WHERE user_id=%s ORDER BY created_at DESC,id LIMIT %s OFFSET %s",
        (u["id"], *pg),
    )


@app.get("/api/notifications")
def notifications(u=Depends(current), db=Depends(connection), pg=Depends(paging)):
    return rows(
        db,
        "SELECT * FROM notifications WHERE user_id=%s ORDER BY created_at DESC,id LIMIT %s OFFSET %s",
        (u["id"], *pg),
    )


@app.get("/api/admin/dashboard")
def dashboard(u=Depends(staff), db=Depends(connection)):
    return one(
        db,
        """SELECT coalesce(sum(grand_total) FILTER(WHERE committed AND status<>'refunded'),0) gross_sales,
      (SELECT coalesce(sum(amount_delta),0) FROM ledger_entries WHERE entry_type IN ('order_payment','deposit_payment','balance_payment','refund')) net_receipts,
      coalesce(sum(balance_due) FILTER(WHERE committed AND status<>'refunded'),0) outstanding,
      (SELECT count(DISTINCT order_id) FROM payments WHERE status='pending') awaiting_verification,
      count(*) FILTER(WHERE committed AND status NOT IN ('refunded','delivered') AND promised_delivery_at BETWEEN now() AND now()+interval '6 hours') near_sla FROM orders""",
    )


@app.get("/api/admin/payments")
def pending(u=Depends(staff), db=Depends(connection), pg=Depends(paging)):
    return rows(
        db,
        "SELECT p.*,o.order_no FROM payments p JOIN orders o ON o.id=p.order_id WHERE p.status='pending' ORDER BY p.created_at,p.id LIMIT %s OFFSET %s",
        pg,
    )


@app.patch("/api/admin/payments/{pid}/verify")
def verify(pid: UUID, b: Decision, u=Depends(admin), db=Depends(connection)):
    return svc.verify(db, pid, b, u["id"])


@app.post("/api/admin/orders/{number}/ship")
def ship(number: str, b: Ship, u=Depends(staff), db=Depends(connection)):
    o = svc.order(db, number)
    svc.require(o["committed"] and o["status"] != "refunded", "NOT_SHIPPABLE")
    s = one(db, "SELECT * FROM shipments WHERE order_id=%s", (o["id"],))
    if s["shipped_at"]:
        svc.require(
            (s["carrier_name"], s["tracking_no"]) == (b.carrier_name, b.tracking_no),
            "ALREADY_SHIPPED",
        )
        return s
    db.execute(
        "UPDATE orders SET status=CASE WHEN status='delayed' THEN status ELSE 'shipped' END WHERE id=%s",
        (o["id"],),
    )
    return one(
        db,
        "UPDATE shipments SET carrier_name=%s,tracking_no=%s,shipped_at=clock_timestamp() WHERE order_id=%s RETURNING *",
        (b.carrier_name, b.tracking_no, o["id"]),
    )


@app.post("/api/admin/orders/{number}/deliver")
def deliver(number: str, u=Depends(staff), db=Depends(connection)):
    o = svc.order(db, number)
    svc.require(o["status"] != "refunded", "ALREADY_REFUNDED")
    s = one(db, "SELECT * FROM shipments WHERE order_id=%s", (o["id"],))
    svc.require(s and s["shipped_at"], "NOT_SHIPPED")
    if not s["delivered_at"]:
        s = one(
            db,
            "UPDATE shipments SET delivered_at=clock_timestamp() WHERE order_id=%s RETURNING *",
            (o["id"],),
        )
        db.execute(
            "UPDATE orders SET status='delivered',delivered_at=%s WHERE id=%s",
            (s["delivered_at"], o["id"]),
        )
        if s["delivered_at"] > o["promised_delivery_at"]:
            svc.compensate(db, svc.order(db, number))
    return svc.order(db, number, lock=False)


@app.post("/api/admin/orders/{number}/sla-compensate")
def compensate(number: str, u=Depends(staff), db=Depends(connection)):
    return {"awarded": 50 if svc.compensate(db, svc.order(db, number)) else 0}


@app.post("/api/admin/orders/{number}/refund")
def refund(number: str, u=Depends(admin), db=Depends(connection)):
    svc.refund(db, svc.order(db, number))
    return {"status": "refunded"}


@app.post("/api/admin/products", status_code=201)
def product(b: Product, u=Depends(admin), db=Depends(connection)):
    p = one(
        db,
        """INSERT INTO products(title,description,category,origin_hub,sla_delivery_hours,is_cold_chain,status)
         VALUES(%s,%s,%s,%s,%s,%s,%s) RETURNING *""",
        (
            b.title,
            b.description,
            b.category,
            b.origin_hub,
            b.sla_delivery_hours,
            b.is_cold_chain,
            b.status,
        ),
    )
    for v in b.variants:
        db.execute(
            """INSERT INTO product_variants(product_id,sku,variant_name,retail_price,wholesale_price,wholesale_min_qty,
        stock_available,require_deposit_pct,weight_grams) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (
                p["id"],
                v.sku,
                v.variant_name,
                v.retail_price,
                v.wholesale_price,
                v.wholesale_min_qty,
                v.stock_available,
                v.require_deposit_pct,
                v.weight_grams,
            ),
        )
    return {
        **p,
        "variants": rows(
            db, "SELECT * FROM product_variants WHERE product_id=%s", (p["id"],)
        ),
    }


@app.patch("/api/admin/variants/{vid}/stock")
def stock(vid: UUID, b: Stock, u=Depends(staff), db=Depends(connection)):
    v = one(
        db,
        "UPDATE product_variants SET stock_available=%s WHERE id=%s AND stock_available=%s RETURNING *",
        (b.stock_available, vid, b.expected_available),
    )
    svc.require(v, "STALE_OR_MISSING_VARIANT")
    return v


@app.get("/api/admin/ledger/export")
def export(u=Depends(admin)):
    def stream():
        with transaction() as db, db.cursor(name="ledger_csv") as cur:
            cur.execute(
                "SELECT id,user_id,order_id,entry_type,amount_delta,points_delta,reference_note,created_at FROM ledger_entries ORDER BY created_at,id"
            )
            buf = StringIO()
            writer = csv.writer(buf)
            writer.writerow([c.name for c in cur.description])
            yield "\ufeff" + buf.getvalue()
            for r in cur:
                buf.seek(0)
                buf.truncate(0)
                note = r["reference_note"]
                if note.lstrip().startswith(("=", "+", "-", "@")):
                    r["reference_note"] = "'" + note
                writer.writerow(r.values())
                yield buf.getvalue()

    return StreamingResponse(
        stream(),
        media_type="text/csv",
        headers={
            "Content-Disposition": "attachment; filename=kram-ledger.csv",
            "Cache-Control": "no-store",
        },
    )
