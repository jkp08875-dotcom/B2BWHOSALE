import os
from contextlib import contextmanager
from dotenv import load_dotenv
from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool

load_dotenv()
pool = ConnectionPool(
    os.environ["DATABASE_URL"],
    min_size=0,
    max_size=int(os.getenv("POOL_SIZE", "12")),
    kwargs={"row_factory": dict_row},
    open=False,
)


@contextmanager
def transaction():
    with pool.connection() as conn:
        with conn.transaction():
            yield conn


def one(db, sql, args=()):
    return db.execute(sql, args).fetchone()


def rows(db, sql, args=()):
    return db.execute(sql, args).fetchall()
