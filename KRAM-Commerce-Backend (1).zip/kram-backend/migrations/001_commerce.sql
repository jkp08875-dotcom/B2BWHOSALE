CREATE DOMAIN thb AS numeric(16,2) CHECK(VALUE >= 0 AND VALUE <> 'NaN'::numeric);
CREATE TABLE users (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), full_name text NOT NULL, phone text UNIQUE NOT NULL,
 email text, role text NOT NULL CHECK(role IN ('customer','wholesaler','affiliate','staff','admin')),
 credit_balance thb NOT NULL DEFAULT 0, points_balance integer NOT NULL DEFAULT 0,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE api_tokens (
 digest text PRIMARY KEY, user_id uuid NOT NULL REFERENCES users, expires_at timestamptz NOT NULL
);
CREATE TABLE products (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),title text NOT NULL,description text NOT NULL DEFAULT '',
 category text NOT NULL,origin_hub text NOT NULL,sla_delivery_hours integer NOT NULL CHECK(sla_delivery_hours>0),
 is_cold_chain boolean NOT NULL DEFAULT false,status text NOT NULL CHECK(status IN ('active','inactive','archived')),
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE product_variants (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),product_id uuid NOT NULL REFERENCES products,sku text UNIQUE NOT NULL,
 variant_name text NOT NULL,retail_price thb NOT NULL CHECK(retail_price>0),
 wholesale_price thb NOT NULL CHECK(wholesale_price>0 AND wholesale_price<=retail_price),
 wholesale_min_qty integer NOT NULL CHECK(wholesale_min_qty>0),
 stock_available integer NOT NULL CHECK(stock_available>=0),stock_reserved integer NOT NULL DEFAULT 0 CHECK(stock_reserved>=0),
 require_deposit_pct integer NOT NULL CHECK(require_deposit_pct IN (0,50)),weight_grams integer NOT NULL CHECK(weight_grams>0)
);
CREATE TABLE media_posts (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),product_id uuid NOT NULL REFERENCES products,
 type text NOT NULL CHECK(type IN ('short_video','live_stream','review_clip')),title text NOT NULL,
 media_url text NOT NULL,thumbnail_url text NOT NULL,view_count bigint NOT NULL DEFAULT 0 CHECK(view_count>=0),
 is_live boolean NOT NULL DEFAULT false CHECK(NOT is_live OR type='live_stream'),created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE vouchers (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),code text UNIQUE NOT NULL CHECK(code=upper(trim(code)) AND code<>''),
 discount_type text NOT NULL CHECK(discount_type IN ('fixed','percent','free_shipping')),discount_value thb NOT NULL,
 min_spend thb NOT NULL,max_quota integer NOT NULL CHECK(max_quota>=0),used_quota integer NOT NULL DEFAULT 0 CHECK(used_quota BETWEEN 0 AND max_quota),
 expires_at timestamptz NOT NULL,is_active boolean NOT NULL DEFAULT true,
 CHECK(discount_type<>'percent' OR discount_value BETWEEN 0.01 AND 100)
);
CREATE TABLE orders (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),order_no text UNIQUE NOT NULL,user_id uuid NOT NULL REFERENCES users,
 affiliate_id uuid REFERENCES users,voucher_id uuid REFERENCES vouchers,status text NOT NULL CHECK(status IN
 ('pending_payment','verifying_slip','deposit_paid','paid','packing','shipped','delivered','delayed','refunded','cancelled')),
 payment_mode text NOT NULL CHECK(payment_mode IN ('full','deposit_50')),
 subtotal thb NOT NULL,shipping_fee thb NOT NULL,discount_amount thb NOT NULL CHECK(discount_amount<=subtotal+shipping_fee),
 grand_total numeric(16,2) GENERATED ALWAYS AS (subtotal+shipping_fee-discount_amount) STORED,
 paid_amount thb NOT NULL DEFAULT 0 CHECK(paid_amount<=subtotal+shipping_fee-discount_amount),
 balance_due numeric(16,2) GENERATED ALWAYS AS (CASE WHEN status IN ('cancelled','refunded') THEN 0 ELSE subtotal+shipping_fee-discount_amount-paid_amount END) STORED,
 expires_at timestamptz NOT NULL,promised_delivery_at timestamptz,delivered_at timestamptz,created_at timestamptz NOT NULL DEFAULT now(),
 committed boolean NOT NULL DEFAULT false,sla_hours integer NOT NULL,origin_snapshot text NOT NULL,
 request_key uuid NOT NULL, request_hash text NOT NULL, UNIQUE(user_id,request_key), UNIQUE(id,user_id)
);
CREATE TABLE order_items (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),order_id uuid NOT NULL REFERENCES orders,variant_id uuid NOT NULL REFERENCES product_variants,
 sku_snapshot text NOT NULL,title_snapshot text NOT NULL,qty integer NOT NULL CHECK(qty>0),unit_price thb NOT NULL,
 total_price numeric(16,2) GENERATED ALWAYS AS(qty*unit_price) STORED,UNIQUE(order_id,variant_id)
);
CREATE TABLE payments (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),order_id uuid NOT NULL REFERENCES orders,
 payment_stage text NOT NULL CHECK(payment_stage IN ('full','deposit','balance')),amount thb NOT NULL CHECK(amount>0),
 slip_image_url text NOT NULL,transfer_ref text NOT NULL UNIQUE,verified_by uuid REFERENCES users,
 verified_at timestamptz,status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
 reject_reason text,created_at timestamptz NOT NULL DEFAULT now(),
 CHECK((status='pending')=(verified_at IS NULL)),CHECK(status<>'approved' OR verified_by IS NOT NULL)
);
CREATE UNIQUE INDEX one_active_slip ON payments(order_id,payment_stage) WHERE status IN ('approved','pending');
CREATE TABLE shipments (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),order_id uuid UNIQUE NOT NULL REFERENCES orders,
 carrier_name text,tracking_no text,origin_hub text NOT NULL,shipped_at timestamptz,delivered_at timestamptz,
 sla_compensated boolean NOT NULL DEFAULT false,UNIQUE(carrier_name,tracking_no)
);
CREATE TABLE ledger_entries (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),user_id uuid NOT NULL REFERENCES users,order_id uuid REFERENCES orders,
 entry_type text NOT NULL CHECK(entry_type IN ('order_payment','deposit_payment','balance_payment','refund',
 'points_checkin','points_redeem','sla_compensation','affiliate_commission')),
 amount_delta numeric(16,2) NOT NULL,points_delta integer NOT NULL,reference_note text NOT NULL,event_key text UNIQUE NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(),CHECK(amount_delta <> 'NaN'::numeric),
 CHECK(CASE WHEN entry_type='refund' THEN amount_delta<0 AND points_delta<=0
 WHEN entry_type IN ('order_payment','deposit_payment','balance_payment','affiliate_commission') THEN amount_delta>0 AND points_delta>=0
 WHEN entry_type='points_redeem' THEN amount_delta=0 AND points_delta<0 ELSE amount_delta=0 AND points_delta>0 END)
);
CREATE FUNCTION prevent_ledger_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'Ledger is append-only'; END $$;
CREATE TRIGGER immutable_ledger BEFORE UPDATE OR DELETE OR TRUNCATE ON ledger_entries FOR EACH STATEMENT EXECUTE FUNCTION prevent_ledger_change();
CREATE FUNCTION post_points() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN IF NEW.points_delta<>0 THEN UPDATE users SET points_balance=points_balance+NEW.points_delta WHERE id=NEW.user_id; END IF;
RETURN NEW; END $$;
CREATE TRIGGER ledger_points AFTER INSERT ON ledger_entries FOR EACH ROW EXECUTE FUNCTION post_points();
CREATE TABLE notifications(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),user_id uuid NOT NULL REFERENCES users,
 order_id uuid NOT NULL REFERENCES orders,message text NOT NULL,created_at timestamptz NOT NULL DEFAULT now(),UNIQUE(order_id,message));
CREATE INDEX expire_queue ON orders(expires_at) WHERE NOT committed AND status IN ('pending_payment','verifying_slip');
CREATE INDEX sla_queue ON orders(promised_delivery_at) WHERE committed;
CREATE INDEX buyer_history ON orders(user_id,created_at DESC);
CREATE INDEX variant_product ON product_variants(product_id);
CREATE INDEX pending_slips ON payments(created_at) WHERE status='pending';
CREATE INDEX ledger_history ON ledger_entries(user_id,created_at DESC);
